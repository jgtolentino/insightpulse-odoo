import io, pytesseract, re
from PIL import Image
from dateutil import parser as dtp

def parse_receipt(content: bytes):
    img = Image.open(io.BytesIO(content))
    text = pytesseract.image_to_string(img)
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    vendor = next((l for l in lines if len(l.split())<=4), lines[0] if lines else "Unknown")
    amount = _extract_amount(lines)
    date = _extract_date(lines)
    return {"vendor": vendor, "amount": amount, "currency": "PHP", "date": date, "raw": text}

def _extract_amount(lines):
    for l in lines[::-1]:
        m = re.search(r'([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?)', l)
        if m: return float(m.group(1).replace(',',''))
    return None

def _extract_date(lines):
    for l in lines:
        try: return dtp.parse(l, fuzzy=True).date().isoformat()
        except: pass
    return None
