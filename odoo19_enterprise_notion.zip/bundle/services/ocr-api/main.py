from fastapi import FastAPI, UploadFile, File
from parsers.receipt import parse_receipt

app = FastAPI()

@app.post("/parse")
async def parse(file: UploadFile = File(...)):
    content = await file.read()
    result = parse_receipt(content)
    return {"ok": True, "data": result}
