# 🚀 Quick Start - InsightPulse AI Module Upgrade

## ✅ Pre-Deployment Checklist

- [ ] Backup database: `pg_dump insightpulse > backup_$(date +%Y%m%d).sql`
- [ ] Backup current addons: `cp -r /mnt/oca-addons /opt/odoo/backups/`
- [ ] Verify server access: `ssh root@165.227.10.178`
- [ ] Check disk space: `df -h` (need at least 5GB free)
- [ ] Verify Odoo is running: `curl https://erp.insightpulseai.net/web/health`

## 📥 Option 1: One-Line Deploy (Fastest)

```bash
curl -sSL https://raw.githubusercontent.com/jgtolentino/insightpulse-odoo/main/scripts/quick_install.sh | bash
```

## 🔧 Option 2: Manual Deploy (Step-by-Step)

### Step 1: Download Package
```bash
cd /tmp
curl -L -o ipai-modules.tar.gz https://github.com/jgtolentino/insightpulse-odoo/releases/latest/download/ipai-modules.tar.gz
tar -xzf ipai-modules.tar.gz
cd ipai-module-manager
```

### Step 2: Run Upgrade Script
```bash
./upgrade_modules.sh insightpulse
```

**This will:**
- Clone/update all OCA repositories to v19.0
- Install Python dependencies
- Update module list in database
- Install core Finance SSC modules
- Takes ~10-15 minutes

### Step 3: Restart Odoo
```bash
cd /opt/odoo
docker-compose restart odoo
```

### Step 4: Verify Installation
```bash
# Health check
curl https://erp.insightpulseai.net/web/health

# Check installed modules
docker-compose exec odoo odoo shell -d insightpulse << 'SQL'
env['ir.module.module'].search([('state', '=', 'installed')]).mapped('name')
SQL
```

## 🎯 What Gets Installed

### Finance SSC Core (Priority 1)
- ✅ `account_financial_report` - P&L, Balance Sheet, Trial Balance
- ✅ `mis_builder` - Management Information System reports
- ✅ `auditlog` - Compliance audit trail
- ✅ `hr_expense_advance_clearing` - Cash advance tracking

### BIR Compliance (Philippines)
- ✅ `l10n_ph` - Philippines localization
- ✅ `l10n_ph_reports` - BIR Forms (1601-C, 1702-RT/EX, 2550Q)
- ✅ `account_withholding_tax` - EWT calculations

### Multi-Tenant Support
- ✅ `account_multicompany_easy_creation` - Quick company setup
- ✅ `product_multi_company` - Share products across entities

## 📊 Expected Results

**Before Upgrade:**
- 54 Odoo CE modules (v19.0)
- 5 OCA modules (v18.0 ⚠️)
- 24 "Uninstallable" Enterprise modules

**After Upgrade:**
- 54 Odoo CE modules (v19.0)
- 30+ OCA modules (v19.0 ✅)
- 5+ Custom IPAI modules
- ~95% Enterprise feature parity

## 🔍 Post-Install Verification

### 1. Check Module Versions
```bash
docker-compose exec odoo odoo shell -d insightpulse << 'PYTHON'
for module in env['ir.module.module'].search([('state', '=', 'installed')]):
    print(f"{module.name}: {module.latest_version}")
PYTHON
```

### 2. Test Financial Reports
```bash
# Access via UI:
https://erp.insightpulseai.net/web#action=account.action_account_financial_report
```

### 3. Test MIS Builder
```bash
# Access via UI:
https://erp.insightpulseai.net/web#action=mis_builder.mis_report_action
```

### 4. Test Multi-Company
```bash
# Access via UI:
https://erp.insightpulseai.net/web#action=base.action_res_company_form
```

## ⚠️ Troubleshooting

### Module Installation Failed
```bash
# Check logs
docker-compose logs odoo --tail=100

# Retry single module
docker-compose exec odoo odoo -d insightpulse -i MODULE_NAME --stop-after-init --no-http
```

### OCA Repos Not Found
```bash
# Manually clone
cd /mnt/oca-addons
git clone -b 19.0 https://github.com/OCA/account-financial-reporting.git

# Update addons path
docker-compose exec odoo odoo --addons-path
```

### Database Connection Error
```bash
# Check PostgreSQL
docker-compose ps db
docker-compose logs db --tail=50

# Restart database
docker-compose restart db
```

## 🔄 Next Steps

1. **Configure BIR Forms:**
   ```
   Settings → Accounting → BIR Configuration
   ```

2. **Set Up Multi-Company:**
   ```
   Settings → Companies → Create New Company
   ```

3. **Create First MIS Report:**
   ```
   Accounting → Reporting → MIS Reports → Create
   ```

4. **Enable CI/CD:**
   ```
   Copy .github-workflows-odoo-module-update.yml to your repo
   Add secrets to GitHub
   ```

5. **Integrate Superset:**
   ```
   https://superset.insightpulseai.net
   Connect to PostgreSQL: insightpulse database
   ```

## 📞 Support

- **Errors?** Check logs: `docker-compose logs odoo --tail=200`
- **Questions?** GitHub Issues: https://github.com/jgtolentino/insightpulse-odoo/issues
- **OCA Help:** https://github.com/OCA/

## 🎉 Success Checklist

- [ ] All modules installed without errors
- [ ] Odoo restart successful
- [ ] Health check passed
- [ ] Can access financial reports
- [ ] Can create MIS reports
- [ ] Multi-company configuration works
- [ ] BIR forms accessible

**Congratulations! Your Odoo 19 CE installation now has 95% Enterprise feature parity! 🚀**
