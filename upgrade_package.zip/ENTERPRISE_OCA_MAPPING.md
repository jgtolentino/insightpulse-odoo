# Odoo Enterprise → OCA Module Mapping

## BIR Compliance & Finance SSC - InsightPulse AI

### Accounting
**Description:** Advanced financial reporting, P&L, Balance Sheet, Trial Balance

**OCA Replacements:**
- `account_financial_report`
- `account_financial_report_qweb`

**Repositories:** account-financial-reporting, account-financial-tools

---

### Account Financial Reports
**Description:** Management Information System reports and financial analysis

**OCA Replacements:**
- `account_financial_report`
- `mis_builder`

**Repositories:** account-financial-reporting

---

### Timesheets
**Description:** Employee timesheet tracking and validation

**OCA Replacements:**
- `hr_timesheet_sheet`
- `hr_timesheet_task_required`

**Repositories:** timesheet

---

### Studio
**Description:** UI customization and low-code development tools

**OCA Replacements:**
- `base_technical_features`
- `web_studio`

**Repositories:** server-tools, web

---

### Field Service
**Description:** On-site service management and scheduling

**OCA Replacements:**
- `fieldservice`
- `fieldservice_account`

**Repositories:** field-service

---

### Helpdesk
**Description:** Customer support ticket management

**OCA Replacements:**
- `helpdesk_mgmt`
- `helpdesk_mgmt_project`

**Repositories:** helpdesk

---

### Sign
**Description:** Digital signature and document agreements

**OCA Replacements:**
- `agreement`
- `agreement_legal`

**Repositories:** contract

---

### Subscriptions
**Description:** Recurring billing and subscription management

**OCA Replacements:**
- `contract`
- `contract_sale`

**Repositories:** contract

---

### Quality
**Description:** Quality control and inspection workflows

**OCA Replacements:**
- `quality_control`
- `quality_control_stock`

**Repositories:** manufacture

---

### Planning
**Description:** Resource planning and shift scheduling

**OCA Replacements:**
- `resource_calendar_school`
- `hr_holidays_public`

**Repositories:** hr, community-data-files

---

### Marketing Automation
**Description:** Automated marketing campaigns and email tracking

**OCA Replacements:**
- `marketing_automation`
- `mail_tracking`

**Repositories:** social, social-marketing-automation

---

### Social Marketing
**Description:** Social media management and posting

**OCA Replacements:**
- `social_media`
- `social_media_facebook`

**Repositories:** social

---

### Appointments
**Description:** Online appointment booking and scheduling

**OCA Replacements:**
- `calendar_event_notify`
- `appointment`

**Repositories:** calendar, project

---

### Appraisal
**Description:** Employee performance reviews and evaluations

**OCA Replacements:**
- `hr_appraisal`
- `hr_appraisal_survey`

**Repositories:** hr

---

### Knowledge
**Description:** Internal knowledge base and documentation

**OCA Replacements:**
- `knowledge`
- `document_page`

**Repositories:** knowledge, management-system

---

### Barcode
**Description:** Barcode scanning for inventory and operations

**OCA Replacements:**
- `stock_barcodes`
- `stock_barcodes_gs1`

**Repositories:** stock-logistics-barcode

---

### Phone
**Description:** VoIP integration and click-to-dial

**OCA Replacements:**
- `crm_phone`
- `asterisk_click2dial`

**Repositories:** connector-telephony

---

### Product Lifecycle Management (PLM)
**Description:** Product engineering change management

**OCA Replacements:**
- `product_variant_configurator`
- `sale_variant_configurator`

**Repositories:** product-variant

---

### MRP II
**Description:** Advanced manufacturing resource planning

**OCA Replacements:**
- `mrp_bom_component_menu`
- `mrp_production_scheduled`

**Repositories:** manufacture

---

