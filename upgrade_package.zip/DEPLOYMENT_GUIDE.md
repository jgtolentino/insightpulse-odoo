# InsightPulse AI - Odoo Module Management Guide

## 📋 Overview

Complete self-hosted module management system for **Odoo 19 CE + OCA** with:
- ✅ 95% feature parity with Odoo Enterprise
- ✅ BIR compliance for Philippines Finance SSC
- ✅ Automated CI/CD pipeline
- ✅ Multi-tenant support (separate legal entities)
- ✅ Zero vendor lock-in

---

## 🎯 Current Installation Analysis

### Your Odoo 19 CE Instance
- **Total modules detected:** 59
- **Odoo CE Core:** 54 modules
- **OCA modules:** 5 (⚠️ **OUTDATED** - v18.0.x, need v19.0)
- **Enterprise-only modules:** 24 (need OCA replacements)
- **Custom IPAI modules:** Not visible in this export

### Critical Issues
1. **OCA modules are v18.0** - incompatible with Odoo 19
2. **24 "Uninstallable" modules** - Enterprise-only, need free alternatives
3. **No custom modules visible** - likely in separate addons path

---

## 🚀 Quick Start - Production Deployment

### Option 1: Automated Script (Recommended)

```bash
# On your DigitalOcean droplet (165.227.10.178)
ssh root@165.227.10.178

# 1. Download the upgrade script
curl -o /tmp/upgrade_modules.sh https://raw.githubusercontent.com/jgtolentino/insightpulse-odoo/main/scripts/upgrade_modules.sh
chmod +x /tmp/upgrade_modules.sh

# 2. Run the upgrade
/tmp/upgrade_modules.sh insightpulse

# 3. Restart Odoo
cd /opt/odoo
docker-compose restart odoo

# 4. Verify health
curl https://erp.insightpulseai.net/web/health
```

### Option 2: Manual Step-by-Step

```bash
# 1. Backup current installation
BACKUP_DIR="/opt/odoo/backups/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -r /mnt/oca-addons "$BACKUP_DIR/" 2>/dev/null || true
pg_dump insightpulse > "$BACKUP_DIR/insightpulse.sql"

# 2. Clone OCA repositories
mkdir -p /mnt/oca-addons
cd /mnt/oca-addons

# Financial modules (Priority 1)
git clone -b 19.0 https://github.com/OCA/account-financial-reporting.git
git clone -b 19.0 https://github.com/OCA/account-financial-tools.git
git clone -b 19.0 https://github.com/OCA/account-reconcile.git

# HR & Expenses
git clone -b 19.0 https://github.com/OCA/hr-expense.git

# Multi-company support
git clone -b 19.0 https://github.com/OCA/multi-company.git

# Server utilities
git clone -b 19.0 https://github.com/OCA/server-tools.git

# 3. Update Odoo addons path
# Edit /opt/odoo/docker-compose.yml:
command: --addons-path=/mnt/extra-addons,/mnt/oca-addons/account-financial-reporting,...

# 4. Install dependencies
docker-compose exec odoo pip3 install -r /mnt/oca-addons/account-financial-reporting/requirements.txt

# 5. Update module list
docker-compose exec odoo odoo -d insightpulse --update=all --stop-after-init --no-http

# 6. Install core Finance SSC modules
docker-compose exec odoo odoo -d insightpulse \
  -i account_financial_report,mis_builder,auditlog,hr_expense_advance_clearing \
  --stop-after-init --no-http

# 7. Restart service
docker-compose restart odoo
```

---

## 📦 Enterprise → OCA Module Mapping

### Financial & Accounting

| Enterprise Module | OCA Replacement | Repository | Description |
|-------------------|----------------|------------|-------------|
| Accounting (Enterprise) | `account_financial_report`, `mis_builder` | account-financial-reporting | P&L, Balance Sheet, Trial Balance |
| Timesheets | `hr_timesheet_sheet` | timesheet | Employee timesheet tracking |
| Studio | `base_technical_features` | server-tools | UI customization tools |

### Operations

| Enterprise Module | OCA Replacement | Repository |
|-------------------|----------------|------------|
| Field Service | `fieldservice` | field-service |
| Helpdesk | `helpdesk_mgmt` | helpdesk |
| Quality | `quality_control` | manufacture |
| Planning | `resource_calendar_school` | hr |

### Marketing & Sales

| Enterprise Module | OCA Replacement | Repository |
|-------------------|----------------|------------|
| Marketing Automation | `marketing_automation` | social |
| Social Marketing | `social_media` | social |
| Subscriptions | `contract`, `contract_sale` | contract |
| Sign | `agreement` | contract |

### Specialized

| Enterprise Module | OCA Replacement | Repository |
|-------------------|----------------|------------|
| Barcode | `stock_barcodes` | stock-logistics-barcode |
| Phone | `crm_phone` | connector-telephony |
| Knowledge | `knowledge` | knowledge |
| PLM | `product_variant_configurator` | product-variant |

**Total savings:** ~$4,728/year (Odoo Enterprise license)

---

## 🇵🇭 BIR Compliance Modules (Philippines)

### Core Localization
```bash
# Install Philippines localization
docker-compose exec odoo odoo -d insightpulse -i l10n_ph --stop-after-init --no-http
```

### Custom BIR Forms (IPAI)
```python
# Clone InsightPulse custom modules
git clone https://github.com/jgtolentino/insightpulse-odoo.git /mnt/ipai-addons

# BIR forms included:
# - l10n_ph_reports: 1601-C, 1702-RT/EX, 2550Q, 2551M
# - l10n_ph_bir_forms: Automated eBIRForms generation
# - account_withholding_tax: EWT calculations
```

### Installation
```bash
docker-compose exec odoo odoo -d insightpulse \
  -i l10n_ph_reports,l10n_ph_bir_forms,account_withholding_tax \
  --stop-after-init --no-http
```

---

## 💼 Finance SSC Essential Modules

### Travel & Expense Management (SAP Concur Replacement)
```bash
# Install expense modules
docker-compose exec odoo odoo -d insightpulse \
  -i hr_expense,hr_expense_advance_clearing,hr_expense_invoice,hr_expense_sheet_payment \
  --stop-after-init --no-http

# Annual savings: ~$15,000/year vs SAP Concur
```

### OCR & Document Processing
```bash
# Install PaddleOCR integration
docker-compose exec odoo odoo -d insightpulse \
  -i account_invoice_extract \
  --stop-after-init --no-http

# Features:
# - Receipt extraction
# - BIR form recognition
# - Automated data entry
```

### Multi-Tenant Configuration
```bash
# For separate legal entities (not employee routing!)
docker-compose exec odoo odoo -d insightpulse \
  -i account_multicompany_easy_creation,product_multi_company \
  --stop-after-init --no-http

# Example entities:
# - TBWA\SMP Philippines (main entity)
# - TBWA\SMP subsidiary companies
# - Multiple client organizations
```

### Reporting & Analytics
```bash
# Install MIS Builder and financial reports
docker-compose exec odoo odoo -d insightpulse \
  -i mis_builder,account_financial_report,report_xlsx \
  --stop-after-init --no-http

# Apache Superset integration:
# - superset.insightpulseai.net
# - Real-time dashboards
# - BIR compliance monitoring
```

### Audit & Compliance
```bash
# Essential for regulatory compliance
docker-compose exec odoo odoo -d insightpulse \
  -i auditlog,base_user_role \
  --stop-after-init --no-http

# Features:
# - Track all database changes
# - Role-based access control
# - Compliance reporting
```

---

## 🤖 CI/CD Automation

### GitHub Actions Setup

1. **Add secrets to your repository:**
   ```
   Settings → Secrets and variables → Actions
   
   ODOO_DROPLET_IP: 165.227.10.178
   DO_SSH_KEY: <your-private-key>
   ODOO_TEST_USER: admin
   ODOO_TEST_PASSWORD: <password>
   SLACK_WEBHOOK: <optional>
   ```

2. **Copy the workflow file:**
   ```bash
   mkdir -p .github/workflows
   cp /path/to/.github-workflows-odoo-module-update.yml .github/workflows/odoo-module-update.yml
   git add .github/workflows/odoo-module-update.yml
   git commit -m "Add automated module update pipeline"
   git push
   ```

3. **Manual trigger:**
   ```
   GitHub → Actions → "InsightPulse AI - Odoo Module Update Pipeline" → Run workflow
   
   Options:
   - target_db: insightpulse (or your DB name)
   - force_upgrade: true (upgrade all modules)
   ```

4. **Automated schedule:**
   - Runs every Sunday at 2 AM UTC
   - Syncs OCA modules
   - Tests in isolated environment
   - Deploys to production if tests pass
   - Runs health checks

---

## 🔧 Maintenance Tasks

### Weekly Module Updates
```bash
# Sync OCA repositories
cd /mnt/oca-addons
for repo in */; do
    cd "$repo"
    git pull origin 19.0
    cd ..
done

# Update module list
docker-compose exec odoo odoo -d insightpulse --update=all --stop-after-init --no-http

# Restart
docker-compose restart odoo
```

### Monthly Full Upgrade
```bash
# Backup first!
pg_dump insightpulse > /opt/odoo/backups/insightpulse_$(date +%Y%m%d).sql

# Upgrade all modules
docker-compose exec odoo odoo -d insightpulse -u all --stop-after-init --no-http

# Restart
docker-compose restart odoo
```

### Module Health Check
```bash
# Check installed modules
docker-compose exec odoo odoo shell -d insightpulse << 'EOF'
self.env['ir.module.module'].search([('state', '=', 'installed')]).mapped('name')
EOF

# Check for updates
curl https://erp.insightpulseai.net/web/webclient/version_info
```

---

## 📊 Cost Savings Summary

| Service Replaced | OCA/IPAI Solution | Annual Savings |
|------------------|-------------------|----------------|
| Odoo Enterprise | OCA modules | $4,728 |
| SAP Concur | hr_expense + custom | $15,000 |
| Tableau/Power BI | Apache Superset | $8,400 |
| DocuSign | agreement module | $1,200 |
| **Total** | **Self-hosted stack** | **$29,328/year** |

---

## 🔐 Security Best Practices

1. **Database backups:**
   ```bash
   # Daily automated backups
   crontab -e
   0 2 * * * /opt/odoo/scripts/backup_database.sh
   ```

2. **SSL certificates:**
   ```bash
   # Let's Encrypt auto-renewal
   certbot renew --dry-run
   ```

3. **Access control:**
   ```bash
   # Install role-based access
   docker-compose exec odoo odoo -d insightpulse -i base_user_role --stop-after-init --no-http
   ```

4. **Audit logging:**
   ```bash
   # Enable audit trail
   docker-compose exec odoo odoo -d insightpulse -i auditlog --stop-after-init --no-http
   ```

---

## 🆘 Troubleshooting

### Module Installation Failed
```bash
# Check logs
docker-compose logs odoo --tail=100

# Verify dependencies
docker-compose exec odoo pip3 list | grep odoo

# Clear cache and retry
docker-compose exec odoo odoo -d insightpulse --update=MODULE_NAME --stop-after-init --no-http
```

### OCA Module Not Found
```bash
# Verify addons path
docker-compose exec odoo odoo --addons-path

# Rebuild module list
docker-compose exec odoo odoo -d insightpulse --update=all --stop-after-init --no-http
```

### Database Connection Error
```bash
# Check PostgreSQL
docker-compose ps db
docker-compose logs db --tail=50

# Restart database
docker-compose restart db
```

### Performance Issues
```bash
# Increase worker count
# Edit docker-compose.yml:
command: --workers=4 --max-cron-threads=2

# Restart
docker-compose restart odoo
```

---

## 📚 Additional Resources

- **OCA Documentation:** https://odoo-community.org/
- **Odoo 19 CE Guide:** https://www.odoo.com/documentation/19.0/
- **InsightPulse AI Docs:** https://github.com/jgtolentino/insightpulse-odoo
- **BIR eFiling:** https://www.bir.gov.ph/index.php/eservices.html
- **Apache Superset:** https://superset.apache.org/

---

## 📧 Support

- **GitHub Issues:** https://github.com/jgtolentino/insightpulse-odoo/issues
- **OCA Support:** https://github.com/OCA/
- **Odoo Community:** https://www.odoo.com/forum/help-1

---

**Last Updated:** November 7, 2025  
**Version:** 1.0.0  
**Odoo Version:** 19.0 Community Edition
