Nothing changes on login action: just select your provider and try to
log in.
