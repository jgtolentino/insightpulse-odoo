This module provides a wizard to allow emptying users password field.

This could be useful to force the user to use another sign on method than Odoo.
