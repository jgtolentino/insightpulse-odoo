To use this module, you need to:

1)  Go to Settings
2)  Go to Users & Companies
3)  Choose the User whose logs you need to see and go to Authentication
    logs
4)  You will see a list of authentications for a specific user
