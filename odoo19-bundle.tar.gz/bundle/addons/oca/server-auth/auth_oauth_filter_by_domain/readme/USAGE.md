1. Go to **Settings > Users and Companies > OAuth Providers**.
2. Add a comma-separated list of domains in the **Allowed Domains** field.
3. Navigate to `/web/login`.  
   - Only providers with `Allowed Domains` matching the current domain will be displayed.  
   - If `Allowed Domains` is left empty, the provider will be visible on all domains.
