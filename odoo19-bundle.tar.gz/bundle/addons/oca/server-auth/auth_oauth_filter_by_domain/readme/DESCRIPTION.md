This module allows to define a list of `allowed_domains` on 'auth.oauth.provider' and shows only the relevant ones matching with the current domain
