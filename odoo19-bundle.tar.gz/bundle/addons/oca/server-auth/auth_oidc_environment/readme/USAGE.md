Once configured, Odoo will read the Auth Providers values from the
configuration.
