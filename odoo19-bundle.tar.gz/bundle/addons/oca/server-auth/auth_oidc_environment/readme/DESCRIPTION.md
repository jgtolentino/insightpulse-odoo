this module allows to use server env for OIDC configuration
