The api key menu is available into Settings \> Technical in debug mode.
By default, when you create an API key, the key is saved into the
database.

If you want to manage them via serve environment settings use
auth_api_key_server_env.
