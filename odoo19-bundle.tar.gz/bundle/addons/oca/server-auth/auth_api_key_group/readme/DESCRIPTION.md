Allow grouping API keys together.

Grouping per se does nothing. This feature is supposed to be used by
other modules to limit access to services or records based on groups of
keys.

The migration of this module from 17.0 to 18.0 was financially supported by Camptocamp.
