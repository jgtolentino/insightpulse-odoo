To use this module, you need to:

- Log out.
- [Sign up](/web/signup) with a valid email.
