On the login page, click on the authentication provider you configured.
