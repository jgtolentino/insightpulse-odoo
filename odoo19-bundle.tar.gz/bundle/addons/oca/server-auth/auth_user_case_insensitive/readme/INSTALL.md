Install this module as you would any other. No further configuration is
required.

Note that upon installation the existing logins will all be converted to
lowercase.
