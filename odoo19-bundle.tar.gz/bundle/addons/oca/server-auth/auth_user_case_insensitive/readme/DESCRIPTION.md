This module makes user logins case insensitive. It also overwrites the
search method to allow these case insensitive logins to work on a
database that previously had case sensitive logins.
