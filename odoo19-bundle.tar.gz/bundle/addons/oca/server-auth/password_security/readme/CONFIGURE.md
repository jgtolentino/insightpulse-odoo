Navigate to General Settings under Configuration Scroll down to the
`Password Policy` section Set the policies to your liking.

Password complexity requirements will be enforced upon next password
change for any user in that company.

**Settings & Defaults**

These are defined at the company level:

[TABLE]
