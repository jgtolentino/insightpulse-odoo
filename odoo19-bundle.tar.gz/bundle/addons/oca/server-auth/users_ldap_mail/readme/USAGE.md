To use this module, you need to:

1.  Open Odoo in your browser
2.  Go to **Settings \> General Settings**
3.  In the **Integrations** section click on **LDAP Server** under
    **LDAP Authentication**. This will allow you to create your LDAP
    integration settings.
4.  When creating or editing a record, under the **Process Parameter**
    section there are two new fields: mail and name, the name of these
    items will correspond with a new user that is created, when a user
    logs in via LDAP in Odoo.
