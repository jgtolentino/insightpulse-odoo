1. In the menu that is displayed when clicking on the user avatar on the top right corner,
   or in the res.users list, click "Switch Login" to impersonate another user.
2. On the top-right corner, the button "Back to Original User" is displayed in case the current
   user is being impersonated.
