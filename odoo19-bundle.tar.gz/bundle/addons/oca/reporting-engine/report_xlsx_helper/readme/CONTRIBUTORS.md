- Luc De Meyer \<<luc.demeyer@noviat.com>\>

- Rattapong Chokmasermkul \<<rattapongc@ecosoft.co.th>\>

- Saran Lim. \<<saranl@ecosoft.co.th>\>

- [Sinerkia Innovación y Desarrollo S.L.](https://www.sinerkia.com):  
  - Luis Pomar
