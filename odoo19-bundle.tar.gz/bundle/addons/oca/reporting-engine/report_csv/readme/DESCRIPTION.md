This module provides a basic report class to generate csv report.
