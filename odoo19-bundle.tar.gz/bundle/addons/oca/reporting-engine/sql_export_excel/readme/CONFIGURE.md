If you want Odoo to update an existing excel file, you should create an
attachment with the excel file and configure this attachment on the
query. Then, you can configure the query to indicate if Odoo should
export the header and where it should insert the data. By default, it
will insert it in the first sheet, at first row/column.
