1.  Add a t-length attribute on report templates fields that will
    truncate the field
2.  Add a t-minlength attribute on report template fields that will
    check the min length
3.  Add a t-maxlength attribute on report template fields that will
    check the max length
