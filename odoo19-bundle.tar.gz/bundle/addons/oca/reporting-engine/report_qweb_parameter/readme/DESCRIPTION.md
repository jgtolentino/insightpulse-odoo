This module allows you to add new parameters on QWeb reports. Currently,
we have defined a field maximum on a report and a validation of maximal
and minimal size. It is useful on xml reports in order to validate
length. XML are sometimes XSD dependant and we must validate its format.
For example, in spanish facturae
(<http://www.facturae.gob.es/Paginas/Index.aspx>), where length and
format must be validated in several fields in order to send an invoice.
