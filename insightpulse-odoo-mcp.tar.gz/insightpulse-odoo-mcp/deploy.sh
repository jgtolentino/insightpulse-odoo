#!/bin/bash

# InsightPulse Odoo MCP - One-Click Deployment Script
# This script sets up everything automatically

set -e

echo "🚀 InsightPulse Odoo MCP Deployment"
echo "===================================="
echo ""

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found"
    echo "Please run this script from the project root directory"
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build TypeScript
echo "🔨 Building TypeScript..."
npm run build

# Test the build
echo "🧪 Testing local mode..."
if [ -f "dist/index.js" ]; then
    echo "✅ Build successful!"
else
    echo "❌ Build failed - dist/index.js not found"
    exit 1
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo ""
    echo "⚠️  No .env file found"
    echo "Creating .env from .env.example..."
    cp .env.example .env
    echo ""
    echo "📝 Please edit .env with your Odoo credentials:"
    echo "   - ODOO_URL"
    echo "   - ODOO_DB"
    echo "   - ODOO_USERNAME"
    echo "   - ODOO_API_KEY"
    echo ""
    read -p "Press Enter after editing .env to continue..."
fi

# Test connection
echo ""
echo "🔌 Testing Odoo connection..."
source .env
if [ -z "$ODOO_URL" ] || [ -z "$ODOO_API_KEY" ]; then
    echo "⚠️  Warning: Environment variables not set properly"
    echo "The MCP server will start but Odoo connection may fail"
fi

# Ask user which mode to deploy
echo ""
echo "Select deployment mode:"
echo "1) Local only (stdio - for Claude Desktop)"
echo "2) Remote only (SSE - for DigitalOcean)"
echo "3) Both (publish to NPM + deploy to DigitalOcean)"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "🏠 Setting up LOCAL mode..."
        echo ""
        echo "Add this to Claude Desktop config:"
        echo ""
        echo '{'
        echo '  "mcpServers": {'
        echo '    "insightpulse-odoo": {'
        echo '      "command": "node",'
        echo '      "args": ["'$(pwd)'/dist/index.js"],'
        echo '      "env": {'
        echo '        "ODOO_URL": "'$ODOO_URL'",'
        echo '        "ODOO_DB": "'$ODOO_DB'",'
        echo '        "ODOO_USERNAME": "'$ODOO_USERNAME'",'
        echo '        "ODOO_API_KEY": "'$ODOO_API_KEY'"'
        echo '      }'
        echo '    }'
        echo '  }'
        echo '}'
        echo ""
        echo "📋 Config copied to clipboard? (manual copy above)"
        echo ""
        echo "✅ Local setup complete!"
        echo "   Restart Claude Desktop to use it"
        ;;
        
    2)
        echo ""
        echo "☁️  Setting up REMOTE mode..."
        echo ""
        
        # Check if doctl is installed
        if ! command -v doctl &> /dev/null; then
            echo "⚠️  doctl not found. Install it:"
            echo "   brew install doctl"
            echo ""
            exit 1
        fi
        
        # Check if authenticated
        if ! doctl account get &> /dev/null; then
            echo "🔑 Authenticating with DigitalOcean..."
            echo "Get your token from: https://cloud.digitalocean.com/account/api/tokens"
            doctl auth init
        fi
        
        # Deploy
        echo ""
        echo "🚀 Deploying to DigitalOcean..."
        echo ""
        
        # Check if app exists
        if [ -z "$DIGITALOCEAN_APP_ID" ]; then
            echo "Creating new app..."
            # App creation logic here
            echo "⚠️  Please create app manually in DigitalOcean console"
            echo "   https://cloud.digitalocean.com/apps/new"
        else
            echo "Updating existing app: $DIGITALOCEAN_APP_ID"
            doctl apps create-deployment $DIGITALOCEAN_APP_ID --wait
        fi
        
        echo ""
        echo "✅ Remote deployment complete!"
        echo "   URL: https://mcp.insightpulseai.net"
        ;;
        
    3)
        echo ""
        echo "📦 Publishing to NPM..."
        
        # Check if logged in to NPM
        if ! npm whoami &> /dev/null; then
            echo "🔑 Please login to NPM:"
            npm login
        fi
        
        # Publish
        echo ""
        echo "Publishing package..."
        npm publish --access public
        
        echo ""
        echo "✅ Published to NPM!"
        echo "   Install with: npx @jgtolentino/insightpulse-odoo-mcp"
        echo ""
        
        # Also deploy to DigitalOcean
        echo "☁️  Also deploying to DigitalOcean..."
        if [ -n "$DIGITALOCEAN_APP_ID" ]; then
            doctl apps create-deployment $DIGITALOCEAN_APP_ID --wait
            echo "✅ Remote deployment complete!"
        fi
        ;;
        
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "🎉 DEPLOYMENT COMPLETE!"
echo ""
echo "📚 Next steps:"
echo "   1. Restart Claude Desktop"
echo "   2. Test with: 'Search for Odoo partners'"
echo "   3. Check health: curl https://mcp.insightpulseai.net/health"
echo ""
echo "📖 Full docs: README.md"
echo "🆘 Quick help: QUICKSTART.md"
echo ""
echo "Happy automating! 🚀"
