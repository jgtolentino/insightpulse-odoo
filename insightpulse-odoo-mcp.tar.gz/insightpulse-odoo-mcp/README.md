# InsightPulse Odoo MCP Server

**Complete Odoo ERP integration for Claude Desktop** - Automate Finance SSC operations, BIR compliance, and multi-agency workflows.

🚀 **Dual-Mode Architecture:**
- **Local Mode (stdio)**: One-click install via `npx` - perfect for Claude Desktop
- **Remote Mode (SSE)**: Deploy to DigitalOcean - access Odoo from anywhere

---

## 🎯 Features

### Finance Operations
- ✅ **Multi-Agency Support**: RIM, CKVC, BOM, JPAL, JLI, JAP, LAS, RMQB
- ✅ **Journal Entries**: Create, search, and manage GL transactions
- ✅ **Bank Reconciliation**: Automated bank statement matching
- ✅ **Trial Balance**: Generate reports by agency or consolidated

### BIR Compliance
- ✅ **Form 1601-C**: Monthly withholding tax
- ✅ **Form 1702-RT/EX**: Annual income tax
- ✅ **Form 2550Q**: Quarterly VAT
- ✅ **Auto-validation**: Check tax calculations before filing

### Integration
- ✅ **Notion Sync**: External ID upsert pattern
- ✅ **Supabase**: Real-time data sync
- ✅ **Claude Desktop**: Natural language queries

---

## 📦 Installation

### Option 1: One-Click Install (Local Mode - Recommended)

Perfect for daily use with Claude Desktop:

```bash
# Install globally via npm
npm install -g @jgtolentino/insightpulse-odoo-mcp

# Or run directly with npx (no installation needed)
npx @jgtolentino/insightpulse-odoo-mcp
```

**Configure Claude Desktop:**

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "insightpulse-odoo": {
      "command": "npx",
      "args": ["-y", "@jgtolentino/insightpulse-odoo-mcp"],
      "env": {
        "ODOO_URL": "https://your-odoo.com",
        "ODOO_DB": "production",
        "ODOO_USERNAME": "your-email@company.com",
        "ODOO_API_KEY": "your-api-key"
      }
    }
  }
}
```

**That's it!** Restart Claude Desktop and you'll see InsightPulse Odoo tools available.

### Option 2: Deploy to DigitalOcean (Remote Mode)

Perfect for team access and production use:

**Step 1: Fork the repository**
```bash
git clone https://github.com/jgtolentino/insightpulse-odoo
cd insightpulse-odoo
```

**Step 2: Create DigitalOcean App**

1. Go to https://cloud.digitalocean.com/apps
2. Click "Create App"
3. Select your GitHub repo: `jgtolentino/insightpulse-odoo`
4. Set build command: `npm run build`
5. Set run command: `npm run start:sse`
6. Add environment variables:
   - `ODOO_URL`
   - `ODOO_DB`
   - `ODOO_USERNAME`
   - `ODOO_API_KEY`
   - `PORT=3000`
7. Deploy!

**Step 3: Connect Claude Desktop to Remote Server**

```json
{
  "mcpServers": {
    "insightpulse-odoo-remote": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/inspector", "https://mcp.insightpulseai.net/sse"]
    }
  }
}
```

---

## 🔧 Configuration

### Getting Your Odoo API Key

1. Login to your Odoo instance
2. Go to **Settings** → **Users & Companies** → **Users**
3. Select your user
4. Go to **API Keys** tab
5. Click "New API Key"
6. Copy the key (save it securely!)

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `ODOO_URL` | Your Odoo instance URL | ✅ Yes |
| `ODOO_DB` | Database name | ✅ Yes |
| `ODOO_USERNAME` | Your Odoo username/email | ✅ Yes |
| `ODOO_API_KEY` | API key from Odoo | ✅ Yes |
| `PORT` | Server port (remote mode only) | Remote only |

---

## 🚀 Usage Examples

### 1. Search for Journal Entries

```
Ask Claude:
"Search for all journal entries from agency RIM in October 2025"
```

Claude will use:
```typescript
odoo_search_records({
  model: "account.move",
  domain: [
    ["analytic_account_id.code", "=", "RIM"],
    ["date", ">=", "2025-10-01"],
    ["date", "<=", "2025-10-31"]
  ],
  fields: ["name", "date", "amount_total", "state"],
  limit: 100
})
```

### 2. Create Month-End Journal Entry

```
Ask Claude:
"Create a journal entry for RIM agency:
- Journal: General Journal (ID: 1)
- Date: 2025-10-31
- Reference: JE-OCT-2025-001

Lines:
1. Debit Rent Expense (account 5010): ₱50,000
2. Credit Cash (account 1010): ₱50,000"
```

### 3. Get BIR Form Data

```
Ask Claude:
"Get BIR Form 1601-C data for CKVC agency for October 2025"
```

Returns tax calculations ready for eFPS filing.

### 4. Generate Trial Balance

```
Ask Claude:
"Generate a consolidated trial balance for all agencies 
from October 1 to October 31, 2025"
```

### 5. Bank Reconciliation

```
Ask Claude:
"Perform bank reconciliation for BOM agency 
using statement ID 123 from Oct 1-31, 2025"
```

---

## 🏗️ Architecture

### Local Mode (stdio)
```
Claude Desktop
     ↓ stdio (JSON-RPC)
InsightPulse Odoo MCP
     ↓ XML-RPC
Your Odoo Instance
```

**Pros:**
- ✅ Zero latency
- ✅ No server needed
- ✅ Works offline
- ✅ One-click install

**Cons:**
- ❌ Only works on your machine
- ❌ No team sharing

### Remote Mode (SSE)
```
Claude Desktop
     ↓ HTTPS/SSE
DigitalOcean App (mcp.insightpulseai.net)
     ↓ XML-RPC
Your Odoo Instance
```

**Pros:**
- ✅ Team access
- ✅ Works from anywhere
- ✅ Centralized logging
- ✅ Auto-scaling

**Cons:**
- ❌ Requires deployment
- ❌ Monthly cost ($5/month)
- ❌ Network latency

---

## 🔄 Workflows

### Month-End Closing

1. **Query pending tasks**
   ```
   "What month-end tasks are pending for all agencies?"
   ```

2. **Post journal entries**
   ```
   "Create accrual journal entries for all agencies"
   ```

3. **Bank reconciliation**
   ```
   "Reconcile bank statements for RIM, CKVC, and BOM"
   ```

4. **Generate reports**
   ```
   "Generate trial balance for October 2025"
   ```

### BIR Filing

1. **Collect tax data**
   ```
   "Get all BIR 1601-C data for October 2025 for all agencies"
   ```

2. **Validate**
   ```
   "Check if all agencies have complete tax data"
   ```

3. **Export**
   ```
   "Export BIR forms in eFPS format"
   ```

---

## 🛠️ Development

### Local Development

```bash
# Clone repo
git clone https://github.com/jgtolentino/insightpulse-odoo
cd insightpulse-odoo

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
# Edit .env with your Odoo credentials

# Build
npm run build

# Test locally
npm start

# Or test remote mode
npm run start:sse
```

### Testing

```bash
# Test MCP server
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | node dist/index.js

# Test health endpoint (remote mode)
curl http://localhost:3000/health
```

---

## 📊 Deployment to DigitalOcean

### App Spec (app.yaml)

```yaml
name: mcp
region: sgp1

services:
  - name: pulse-hub-api
    github:
      repo: jgtolentino/insightpulse-odoo
      branch: main
      deploy_on_push: true
    
    build_command: npm run build
    run_command: npm run start:sse
    
    environment_slug: node-js
    instance_size_slug: basic-xxs
    instance_count: 1
    
    http_port: 3000
    
    routes:
      - path: /
      - path: /health
      - path: /sse
      - path: /messages
    
    envs:
      - key: PORT
        value: "3000"
      - key: NODE_ENV
        value: "production"
      - key: ODOO_URL
        value: "${ODOO_URL}"
        type: SECRET
      - key: ODOO_DB
        value: "${ODOO_DB}"
        type: SECRET
      - key: ODOO_USERNAME
        value: "${ODOO_USERNAME}"
        type: SECRET
      - key: ODOO_API_KEY
        value: "${ODOO_API_KEY}"
        type: SECRET

  - name: pulse-hub
    github:
      repo: jgtolentino/insightpulse-odoo
      branch: main
      deploy_on_push: true
    static_sites:
      - name: docs
        source_dir: docs
        build_command: npm run build:docs
```

### GitHub Actions Auto-Deploy

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to DigitalOcean

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install doctl
        uses: digitalocean/action-doctl@v2
        with:
          token: ${{ secrets.DIGITALOCEAN_ACCESS_TOKEN }}
      
      - name: Trigger deployment
        run: doctl apps create-deployment ${{ secrets.APP_ID }} --wait
```

---

## 🔐 Security

### Best Practices

1. **Never commit API keys** - Use environment variables
2. **Use Odoo API keys** - Not passwords
3. **Rotate keys quarterly**
4. **Enable 2FA** on Odoo account
5. **Use HTTPS** for remote mode
6. **Restrict API key permissions** - Read/write only what's needed

### Row-Level Security (Odoo)

Configure access rules per agency:
```python
# In Odoo custom module
record_rules = [
    {
        'name': 'RIM Users - Own Agency Only',
        'model_id': 'account.move',
        'domain_force': "[('analytic_account_id.code', '=', user.agency_code)]"
    }
]
```

---

## 📈 Monitoring

### Health Checks

```bash
# Local mode
echo '{"jsonrpc":"2.0","id":1,"method":"ping"}' | node dist/index.js

# Remote mode
curl https://mcp.insightpulseai.net/health
```

### DigitalOcean Monitoring

- **CPU/RAM**: Dashboard → Your App → Insights
- **Logs**: Dashboard → Your App → Runtime Logs
- **Uptime**: Dashboard → Your App → Activity

### Sentry Integration

```typescript
import * as Sentry from "@sentry/node";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
});
```

---

## 🆘 Troubleshooting

### "Authentication failed"

**Cause**: Invalid Odoo credentials

**Solution**:
1. Verify `ODOO_URL` is correct (include https://)
2. Check `ODOO_DB` name matches exactly
3. Regenerate API key in Odoo
4. Test with curl:
   ```bash
   curl -X POST https://your-odoo.com/jsonrpc \
     -H "Content-Type: application/json" \
     -d '{"jsonrpc":"2.0","method":"call","params":{"service":"common","method":"authenticate","args":["DB","USER","KEY",{}]}}'
   ```

### "MCP Server Not Appearing in Claude"

**Solution**:
1. Check Claude Desktop logs:
   ```bash
   tail -f ~/Library/Logs/Claude/mcp.log
   ```
2. Verify JSON syntax in config
3. Restart Claude Desktop
4. Test MCP server manually

### "Port 3000 already in use"

**Solution**:
```bash
# Kill existing process
lsof -ti:3000 | xargs kill -9

# Or use different port
PORT=3001 npm run start:sse
```

---

## 🤝 Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing`)
5. Open Pull Request

---

## 📄 License

MIT License - see [LICENSE](LICENSE) file

---

## 🎯 Roadmap

- [x] Local stdio support
- [x] Remote SSE support  
- [x] Basic Odoo operations
- [x] BIR form support
- [ ] XML-RPC client (replace mock)
- [ ] Advanced bank reconciliation
- [ ] Multi-currency support
- [ ] Expense management module
- [ ] Travel request workflows
- [ ] Mobile notifications
- [ ] Real-time Odoo webhooks
- [ ] AI-powered anomaly detection

---

## 📞 Support

- **Documentation**: https://insightpulseai.net/docs
- **Issues**: https://github.com/jgtolentino/insightpulse-odoo/issues
- **Email**: jake@insightpulseai.net
- **Notion**: [Project Board](https://notion.so/insightpulse-odoo)

---

**Built with ❤️ for Finance Shared Service Centers**

Automate your Odoo workflows with AI  
Save time on month-end closing, BIR compliance, and multi-agency operations

---

## Quick Links

- 🚀 [One-Click Install](#option-1-one-click-install-local-mode---recommended)
- ☁️ [Deploy to DigitalOcean](#option-2-deploy-to-digitalocean-remote-mode)
- 📖 [Usage Examples](#-usage-examples)
- 🔧 [Configuration](#-configuration)
- 🆘 [Troubleshooting](#-troubleshooting)
